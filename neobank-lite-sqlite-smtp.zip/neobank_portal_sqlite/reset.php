<?php require_once __DIR__ . '/helper.php'; require_once __DIR__ . '/db.php';
$token=$_GET['token']??$_POST['token']??null; $ok=false; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){ $new=$_POST['password']??''; if($token && $new){ $updated=user_set_password_by_token($token, password_hash($new,PASSWORD_BCRYPT)); if($updated>0) $ok=true; else $err='رابط غير صالح.'; } else { $err='بيانات ناقصة.'; } }
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>إعادة تعيين كلمة المرور</title><link rel="stylesheet" href="assets/css/style.css"></head><body class="bg"><div class="card"><h1 class="title">إعادة تعيين كلمة المرور</h1>
<?php if($ok): ?><div class="alert">تم تغيير كلمة المرور بنجاح. <a class="link" href="index.php">سجّل الدخول</a></div><?php else: ?><?php if($err): ?><div class="alert"><?php echo h($err); ?></div><?php endif; ?>
<form method="post" class="form"><input type="hidden" name="token" value="<?php echo h($token); ?>"><label>كلمة مرور جديدة</label><input type="password" name="password" required><button class="btn" type="submit">تأكيد</button></form><?php endif; ?></div></body></html>
