# HL: Prison Break — Docker Escape (Stage 1 included)

**Offline-friendly** setup. No external CDNs/links in the UI. Local assets included (SVG placeholders).
You can prefetch Python packages (wheels) using the provided script to build without internet (*except for pulling the base Docker image if not already cached*).

## Structure
```
hl_prison_break/
 ├─ docker-compose.yml
 ├─ README.md
 ├─ scripts/
 │   └─ bootstrap_offline_vendor.sh
 ├─ portal/
 │   ├─ Dockerfile
 │   ├─ requirements.txt
 │   ├─ app.py
 │   ├─ templates/
 │   │   ├─ base.html
 │   │   ├─ index.html
 │   │   └─ partials/flash.html
 │   └─ static/
 │       ├─ styles.css
 │       └─ img/
 │           ├─ cell-hero.svg
 │           ├─ thumb-1.svg
 │           └─ thumb-2.svg
 ├─ shared/               (mounted read-write)
 ├─ flags/
 │   ├─ flagA.txt
 │   ├─ flagB.txt
 │   └─ flagC.txt
 ├─ runner/               (placeholder)
 ├─ docker-proxy/         (placeholder)
 ├─ monitor-lite/         (placeholder)
 └─ sibling-app/          (placeholder)
```

## Flags (static)
- **A**: `HL{PRISON_BREAK_INITIATED_DOCKER_WALLS_CANNOT_HOLD_ME}`
- **B**: `HL{THE_HOST_SEES_ALL_BUT_REVEALS_ONLY_TO_THE_CLEVER_ESCAPIST}`
- **C**: `HL{ULTIMATE_ESCAPE_COMPLETE_THE_CHAINS_OF_CONTAINERS_ARE_SHATTERED}`

> For the full challenge later:
> - A will be embedded inside sibling-app at `/opt/flag.txt`.
> - B should be placed on the host at `/opt/maintenance/flagB.txt` (bind-mounted read-only).
> - C should live at `/root/flagC.txt` on the host.

## Build without internet (Python deps)
Before building, you can fetch Python wheels on any machine with internet and copy the resulting `portal/vendor/` folder over:
```bash
cd scripts
bash bootstrap_offline_vendor.sh
# copies wheels into ../portal/vendor
```

The `portal/Dockerfile` will attempt offline install first:
```
pip install --no-index --find-links /app/vendor -r requirements.txt || pip install -r requirements.txt
```

## Run Stage 1 (Portal)
```bash
docker compose up -d --build
# open http://SERVER_IP:8080/
```

## Notes
- No external CSS/JS/fonts/CDNs.
- Images are local SVG placeholders (edit/replace with your own at `portal/static/img/`).
- For production, swap Flask dev server with a WSGI server (e.g., gunicorn/uwsgi) if desired.
