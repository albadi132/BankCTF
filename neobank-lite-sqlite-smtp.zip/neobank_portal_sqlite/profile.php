<?php require_once __DIR__ . '/helper.php'; require_login(); session_start();
$u=user_find_by_id($_SESSION['user_id']); ?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>الملف الشخصي</title><link rel="stylesheet" href="assets/css/style.css"></head><body class="bg"><div class="card">
<h1 class="title">الملف الشخصي</h1><div class="form">
<div class="readonly"><strong>الاسم:</strong> <?php echo h($u['name']); ?></div>
<div class="readonly"><strong>البريد:</strong> <?php echo h($u['email']); ?></div>
<div class="readonly"><strong>الحالة:</strong> <?php echo empty($u['email_verified_at'])?'غير مفعّل':'مفعّل'; ?></div>
</div><a class="link" href="dashboard.php">رجوع</a></div></body></html>
