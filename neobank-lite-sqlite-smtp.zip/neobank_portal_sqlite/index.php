<?php session_start(); $err=$_GET['err']??''; $ok=$_GET['ok']??''; ?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>بوابة البنك – تسجيل الدخول</title><link rel="stylesheet" href="assets/css/style.css"></head><body class="bg">
<div class="card"><div class="brand">NeoBank<span>Lite</span></div><h1 class="title">تسجيل الدخول</h1>
<?php if($ok): ?><div class="alert"><?php echo h($ok); ?></div><?php endif; ?>
<?php if($err): ?><div class="alert"><?php echo h($err); ?></div><?php endif; ?>
<form action="login.php" method="post" class="form">
<label>البريد الإلكتروني</label><input type="email" name="email" required placeholder="you@example.com">
<label>كلمة المرور</label><input type="password" name="password" required placeholder="••••••••">
<button class="btn" type="submit">دخول</button>
<div class="row"><a class="link" href="register.php">إنشاء حساب</a><a class="link" href="forgot.php">نسيت كلمة المرور؟</a></div>
</form><footer class="foot"><img src="assets/imgs/lock.svg" class="icon"><span>بيئة تدريبية (CTF).</span></footer></div></body></html>
