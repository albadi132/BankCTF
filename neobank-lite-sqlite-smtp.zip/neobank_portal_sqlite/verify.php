<?php require_once __DIR__ . '/helper.php'; require_once __DIR__ . '/db.php';
$token=$_GET['token']??''; $u=$token?user_find_by_verify_token($token):null;
$msg=$u?'تم تفعيل بريدك بنجاح. يمكنك تسجيل الدخول الآن.':'رابط غير صالح أو مستخدم مسبقًا.';
if($u) user_mark_verified($u['id']); header('Location:/index.php?ok='.urlencode($msg)); exit; ?>