import os
import pathlib
import secrets
from urllib.parse import urlparse

import requests
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory

PORT = int(os.getenv("PORT", "8080"))
SHARED_DIR = pathlib.Path(os.getenv("SHARED_DIR", "/srv/shared")).resolve()
SHARED_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET", secrets.token_hex(16))

ALLOWED_EXT = {"png", "jpg", "jpeg", "gif", "txt", "md", "json", "yaml", "yml", "csv"}
MAX_SIZE_MB = 5

def safe_filename(name: str) -> str:
    # light normalization; not fully safe by design (challenge flavor)
    name = name.strip().replace("..", ".")
    name = name.replace("/", "-").replace("\\", "-")
    return name[:120] or "file"

@app.get("/")
def index():
    items = []
    for p in sorted(SHARED_DIR.glob("*")):
        if p.is_file():
            items.append(p.name)
    return render_template("index.html", items=items)

@app.post("/upload")
def upload_file():
    f = request.files.get("file")
    if not f or not f.filename:
        flash("Choose a file to upload.", "warning")
        return redirect(url_for("index"))

    name = safe_filename(f.filename)
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext and ext not in ALLOWED_EXT:
        flash("File type not allowed.", "danger")
        return redirect(url_for("index"))

    data = f.read()
    if len(data) > MAX_SIZE_MB * 1024 * 1024:
        flash("File too large.", "danger")
        return redirect(url_for("index"))

    (SHARED_DIR / name).write_bytes(data)
    flash(f"Uploaded: {name}", "success")
    return redirect(url_for("index"))

@app.post("/import-url")
def import_url():
    url = (request.form.get("url") or "").strip()
    if not url:
        flash("Provide a URL to import.", "warning")
        return redirect(url_for("index"))
    try:
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            flash("Only http/https URLs are allowed.", "danger")
            return redirect(url_for("index"))

        resp = requests.get(url, timeout=5)
        resp.raise_for_status()
        name = safe_filename(os.path.basename(parsed.path) or f"import_{secrets.token_hex(4)}.txt")
        (SHARED_DIR / name).write_bytes(resp.content)
        flash(f"Imported from URL into: {name}", "success")
    except Exception as e:
        flash(f"Import failed: {e}", "danger")
    return redirect(url_for("index"))

@app.get("/shared/<path:fname>")
def get_shared(fname: str):
    fname = safe_filename(fname)
    return send_from_directory(SHARED_DIR, fname, as_attachment=False)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT)
