<?php require_once __DIR__ . '/helper.php'; require_once __DIR__ . '/db.php'; require_once __DIR__ . '/mail.php';
$msg=''; if($_SERVER['REQUEST_METHOD']==='POST'){ $email=$_POST['email']??''; $u=user_find_by_email($email);
  if($u){ $token=compute_reset_token($u['email']); $link=rtrim((require __DIR__.'/config/env.php')['app_url'],'/').'/reset.php?token='.$token;
    $subject='إعادة تعيين كلمة المرور – NeoBank Lite'; $html='<div style="font-family:Tahoma,Arial,sans-serif;line-height:1.6"><h3>إعادة التعيين</h3><p><a href="'.h($link).'">اضغط هنا</a></p><p>أو: '.h($link).'</p><hr><p>تحقق من مجلد السبام.</p></div>'; send_mail($email,$subject,$html); }
  $msg='إذا كان البريد مسجّلًا ستصلك رسالة تتضمن رابط إعادة التعيين. تحقق من مجلد السبام إن لم تظهر.'; }
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>استرجاع كلمة المرور</title><link rel="stylesheet" href="assets/css/style.css"></head><body class="bg"><div class="card"><h1 class="title">نسيت كلمة المرور</h1>
<?php if($msg): ?><div class="alert"><?php echo h($msg); ?></div><?php endif; ?>
<form method="post" class="form"><label>البريد الإلكتروني</label><input type="email" name="email" required><button class="btn" type="submit">إرسال الرابط</button></form>
<div class="hint">تحقق من مجلد السبام إن لم تصلك الرسالة.</div></div></body></html>
