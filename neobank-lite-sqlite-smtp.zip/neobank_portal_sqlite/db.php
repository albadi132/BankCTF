<?php
function db() : PDO {
    static $pdo=null;
    if($pdo) return $pdo;
    $path=__DIR__.'/data/app.db';
    $pdo=new PDO('sqlite:'.$path);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        email_verified_at TEXT NULL,
        verify_token TEXT NULL,
        created_at TEXT NOT NULL
    )");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_users_verify_token ON users(verify_token)");
    return $pdo;
}
function user_create($name,$email,$hash,$token){ $st=db()->prepare("INSERT INTO users(name,email,password_hash,verify_token,created_at) VALUES(?,?,?,?,datetime('now'))"); $st->execute([$name,strtolower($email),$hash,$token]); return db()->lastInsertId(); }
function user_find_by_email($email){ $st=db()->prepare("SELECT * FROM users WHERE lower(email)=lower(?) LIMIT 1"); $st->execute([$email]); return $st->fetch(PDO::FETCH_ASSOC)?:null; }
function user_find_by_id($id){ $st=db()->prepare("SELECT * FROM users WHERE id=? LIMIT 1"); $st->execute([$id]); return $st->fetch(PDO::FETCH_ASSOC)?:null; }
function user_find_by_verify_token($t){ $st=db()->prepare("SELECT * FROM users WHERE verify_token=? LIMIT 1"); $st->execute([$t]); return $st->fetch(PDO::FETCH_ASSOC)?:null; }
function user_mark_verified($id){ $st=db()->prepare("UPDATE users SET email_verified_at=datetime('now'), verify_token=NULL WHERE id=?"); $st->execute([$id]); }
function user_set_password_by_token($token,$newhash){ $st=db()->prepare("UPDATE users SET password_hash=? WHERE EXISTS (SELECT 1 FROM users u WHERE u.email=users.email AND substr(sha1(lower(u.email) || ?),1,8)=?)"); $st->execute([$newhash, app_config('reset_salt'), $token]); return $st->rowCount(); }
function compute_reset_token($email){ return substr(sha1(strtolower($email).app_config('reset_salt')),0,8); }
function app_config($key){ static $env=null; if(!$env) $env=require __DIR__.'/config/env.php'; return $env[$key]??null; }
?>