<?php
require_once __DIR__ . '/helper.php'; session_start();
$email=$_POST['email']??''; $pass=$_POST['password']??'';
$user=user_find_by_email($email);
if(!$user || !password_verify($pass, $user['password_hash'])){ header('Location:/index.php?err='.urlencode('بيانات الدخول غير صحيحة')); exit; }
if(empty($user['email_verified_at'])){ header('Location:/index.php?err='.urlencode('يرجى تفعيل بريدك أولًا. تحقق من السبام.')); exit; }
$_SESSION['pending_uid']=$user['id']; header('Location:/otp.php'); exit; ?>