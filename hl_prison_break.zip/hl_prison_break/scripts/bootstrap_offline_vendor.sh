#!/usr/bin/env bash
set -euo pipefail

# This script downloads Python wheels for offline install.
# Run it on any machine WITH internet, then copy the 'portal/vendor' folder
# into your target environment.
#
# Requires: python3 -m pip

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PORTAL_DIR="$ROOT_DIR/portal"
VENDOR_DIR="$PORTAL_DIR/vendor"

mkdir -p "$VENDOR_DIR"
cd "$VENDOR_DIR"

# Download wheels for all dependencies listed in requirements.txt (and their deps)
python3 -m pip download --only-binary=:all: -r "$PORTAL_DIR/requirements.txt"

echo "✅ Wheels downloaded into: $VENDOR_DIR"
echo "You can now build the Docker image offline."
