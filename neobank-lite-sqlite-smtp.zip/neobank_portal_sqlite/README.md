# NeoBank Lite (CTF) — SQLite + SMTP Registration
- تسجيل حقيقي عبر SQLite + تفعيل بريد عبر SMTP (Mailcow).
- ثغرات CTF: إعادة تعيين كلمة المرور عبر token فقط (sha1(email+'minty')), 2FA بــ OTP حتمي لكل ساعة، وwkhtmltopdf command injection.

## التشغيل
php -S 0.0.0.0:8000 -t neobank_portal_sqlite

## ملاحظات
- SMTP مضبوط في config/env.php (استعملت القيم التي زوّدتني بها). **من الأفضل تدوير كلمة المرور بعد الاختبار.**
- إذا لم تُثبّت PHPMailer عبر Composer، سيتم حفظ الرسائل في مجلد mailbox/ كبديل.
- SQLite تُنشأ تلقائيًا في data/app.db.
