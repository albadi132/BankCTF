Monitor-lite placeholder. Static HTML to be added later.
