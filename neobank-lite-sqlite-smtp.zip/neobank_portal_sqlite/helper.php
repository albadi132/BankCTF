<?php
require_once __DIR__ . '/db.php';
function h($s){ return htmlspecialchars($s??'', ENT_QUOTES, 'UTF-8'); }
function require_login(){ session_start(); if(empty($_SESSION['user_id'])){ header('Location:/index.php'); exit; } }
function otp_for_email($email){ $seed=strtolower($email).date('Y-m-d-H'); $n=sprintf('%u', crc32($seed)); $otp=((int)$n)%1000000; return str_pad((string)$otp,6,'0',STR_PAD_LEFT); }
?>