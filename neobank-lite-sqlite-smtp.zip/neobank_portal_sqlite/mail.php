<?php
use PHPMailer\PHPMailer\PHPMailer; use PHPMailer\PHPMailer\Exception;
function send_mail($to,$subject,$html){
  $env = require __DIR__ . '/config/env.php';
  $host=$env['smtp_host']; $port=$env['smtp_port']; $secure=$env['smtp_secure'];
  $user=$env['smtp_user']; $pass=$env['smtp_pass']; $from=$env['smtp_from']; $fromName=$env['smtp_from_name'];
  // Try PHPMailer if installed via Composer
  $autoload=__DIR__.'/vendor/autoload.php';
  if(file_exists($autoload)){ require_once $autoload;
    $mail=new PHPMailer(true);
    try{
      $mail->isSMTP(); $mail->Host=$host; $mail->Port=$port; $mail->SMTPAuth=true; $mail->Username=$user; $mail->Password=$pass; $mail->CharSet='UTF-8';
      $mail->SMTPSecure = ($secure==='ssl') ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
      $mail->setFrom($from,$fromName); $mail->addAddress($to);
      $mail->isHTML(true); $mail->Subject=$subject; $mail->Body=$html; $mail->AltBody=strip_tags($html); $mail->send(); return true;
    } catch (Exception $e){ /* fallback */ }
  }
  // Fallback to mailbox folder
  $fname = __DIR__.'/mailbox/'.preg_replace('/[^a-z0-9_.@-]+/i','_', $to).'_'.time().'.eml';
  $content="To: $to\nSubject: $subject\nContent-Type: text/html; charset=UTF-8\n\n$html\n";
  return (bool)file_put_contents($fname,$content);
}
?>