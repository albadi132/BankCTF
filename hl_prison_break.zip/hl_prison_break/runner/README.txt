Runner service placeholder. Implement in Stage 2.
