<?php require_once __DIR__ . '/helper.php'; require_login(); session_start();
$uid=$_SESSION['user_id']; $month=$_GET['month']??date('Y-m'); $note=$_GET['note']??''; $base=rtrim((require __DIR__.'/config/env.php')['app_url'],'/');
$url=$base."/statement_template.php?uid=$uid&month=$month&note=".$note; $out="/tmp/statement_$uid.pdf";
$cmd="wkhtmltopdf --quiet ".$url." ".$out; shell_exec($cmd);
if(file_exists($out)){ header('Content-Type: application/pdf'); header('Content-Disposition: attachment; filename="statement-'.$month.'.pdf"'); readfile($out); unlink($out); exit; }
header('Content-Type:text/plain; charset=utf-8'); echo "فشل إنشاء الملف\n$cmd\n"; 