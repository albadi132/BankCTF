<?php
define('WKHTMLTOPDF_PATH', 'wkhtmltopdf');
?>