<?php
return [
  'smtp_host' => '213.136.85.48',
  'smtp_port' => 587,
  'smtp_secure' => 'tls',
  'smtp_user' => 'soor@lab.spacetechno.om',
  'smtp_pass' => 'eFINseWAglUcIndIftSurgenTLetTswE70',
  'smtp_from' => 'soor@lab.spacetechno.om',
  'smtp_from_name' => 'NeoBank Lite',
  'app_url' => 'http://localhost:8000',
  'reset_salt' => 'minty'
];