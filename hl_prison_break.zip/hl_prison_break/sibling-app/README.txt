Sibling-app placeholder. Will contain /opt/flag.txt inside image in later stage.
