<?php
require_once __DIR__ . '/helper.php'; require_once __DIR__ . '/db.php'; require_once __DIR__ . '/mail.php';
$ok=''; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=trim($_POST['name']??''); $email=trim($_POST['email']??''); $pass=$_POST['password']??'';
  if(!$name||!$email||!$pass){ $err='يرجى تعبئة جميع الحقول.'; }
  elseif(user_find_by_email($email)){ $err='البريد مستخدم بالفعل.'; }
  else{
    $hash=password_hash($pass, PASSWORD_BCRYPT); $token=bin2hex(random_bytes(16)); user_create($name,$email,$hash,$token);
    $env=require __DIR__.'/config/env.php'; $link=rtrim($env['app_url'],'/').'/verify.php?token='.$token;
    $subject='تفعيل حسابك في NeoBank Lite'; $html='<div style="font-family:Tahoma,Arial,sans-serif;line-height:1.6"><h2>أهلًا '.h($name).'</h2><p>لتفعيل حسابك اضغط:</p><p><a href="'.h($link).'" style="background:#22d3ee;color:#04202a;padding:10px 16px;border-radius:10px;text-decoration:none;font-weight:bold">تفعيل الحساب</a></p><p>أو استخدم الرابط: '.h($link).'</p><hr><p><strong>تنبيه:</strong> إن لم تجد الرسالة، افحص مجلد <em>السبام/البريد غير الهام</em> ثم ضع علامة "ليس سبام".</p></div>';
    if(send_mail($email,$subject,$html)){ $ok='تم إنشاء الحساب. تحقق من بريدك لتفعيل الحساب (ولا تنسَ فحص مجلد السبام).'; } else { $err='تعذّر إرسال رسالة التفعيل. تحقق من إعدادات SMTP.'; }
  }
}
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>إنشاء حساب</title><link rel="stylesheet" href="assets/css/style.css"></head><body class="bg"><div class="card">
<h1 class="title">إنشاء حساب جديد</h1><?php if($ok): ?><div class="alert"><?php echo h($ok); ?></div><?php endif; ?><?php if($err): ?><div class="alert"><?php echo h($err); ?></div><?php endif; ?>
<form method="post" class="form"><label>الاسم الكامل</label><input type="text" name="name" required><label>البريد الإلكتروني</label><input type="email" name="email" required><label>كلمة المرور</label><input type="password" name="password" required><button class="btn" type="submit">تسجيل</button></form>
<div class="hint">إذا لم تجد رسالة التفعيل، افحص مجلد السبام/البريد غير الهام.</div><div class="row spaced"><a class="link" href="index.php">عودة لتسجيل الدخول</a></div></div></body></html>
