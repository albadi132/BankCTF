<?php require_once __DIR__ . '/helper.php'; require_login(); session_start();
$user=user_find_by_id($_SESSION['user_id']); $month=date('Y-m'); ?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>لوحة التحكم</title><link rel="stylesheet" href="assets/css/style.css"></head><body class="bg"><div class="card">
<div class="brand small">NeoBank<span>Lite</span></div><h1 class="title">مرحبًا، <?php echo h($user['name']); ?></h1>
<div class="grid"><div class="kpi"><div class="kpi-title">الرصيد الحالي</div><div class="kpi-value">1,230.450 ر.ع</div></div>
<div class="kpi"><div class="kpi-title">آخر حركة</div><div class="kpi-value">+120.500 ر.ع</div></div>
<div class="kpi"><div class="kpi-title">حالة الحساب</div><div class="kpi-value ok">نشط</div></div></div>
<h2 class="subtitle">تحميل كشف الحساب (PDF)</h2>
<form class="form" action="download_statement.php" method="get"><label>الشهر</label><input type="month" name="month" value="<?php echo h($month); ?>"><label>ملاحظة</label><input type="text" name="note" placeholder="مثال: طلب توثيق"><button class="btn" type="submit">تنزيل PDF</button></form>
<div class="row spaced"><a class="link" href="profile.php">الملف الشخصي</a><a class="link" href="logout.php">تسجيل الخروج</a></div></div></body></html>
