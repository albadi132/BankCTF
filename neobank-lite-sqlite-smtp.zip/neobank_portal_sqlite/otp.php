<?php require_once __DIR__ . '/helper.php'; session_start();
$pending=$_SESSION['pending_uid']??null; if(!$pending){ header('Location:/index.php'); exit; }
$user=user_find_by_id($pending); if(!$user){ header('Location:/index.php'); exit; }
$info=''; if($_SERVER['REQUEST_METHOD']==='POST'){ $otp=$_POST['otp']??''; if($otp===otp_for_email($user['email'])){ $_SESSION['user_id']=$user['id']; $_SESSION['pending_uid']=null; header('Location:/dashboard.php'); exit; } else { $info='رمز التحقق غير صحيح'; } }
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>رمز التحقق</title><link rel="stylesheet" href="assets/css/style.css"></head><body class="bg"><div class="card">
<h1 class="title">التحقق بخطوتين</h1><p class="muted">أدخل الرمز المرسل لبريدك.</p>
<?php if($info): ?><div class="alert"><?php echo h($info); ?></div><?php endif; ?>
<form method="post" class="form"><label>الرمز</label><input type="text" name="otp" inputmode="numeric" pattern="\d{6}" placeholder="000000" required><button class="btn" type="submit">تأكيد</button></form>
<div class="hint">إن لم تصلك الرسالة، افحص مجلد السبام.</div></div></body></html>
